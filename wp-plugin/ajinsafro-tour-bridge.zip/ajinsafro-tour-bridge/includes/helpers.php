<?php
/**
 * Helper Functions
 *
 * @package AjinsafroTourBridge
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Laravel API base URL for voyage flights (optional).
 * Define AJTB_LARAVEL_API_URL or use filter 'ajtb_laravel_api_url'.
 *
 * @return string Empty if not configured (e.g. same-server DB only).
 */
function ajtb_laravel_api_url() {
    $url = defined('AJTB_LARAVEL_API_URL') ? AJTB_LARAVEL_API_URL : '';
    return (string) apply_filters('ajtb_laravel_api_url', $url);
}

/**
 * Get full table name for aj_* tables. Prevents double prefix.
 *
 * @param string $suffix Table name suffix, e.g. 'aj_tour_activity_selections', 'aj_tour_days', 'aj_activities'
 * @return string Full table name (e.g. {$wpdb->prefix}aj_tour_activity_selections)
 */
function ajtb_table($suffix) {
    global $wpdb;
    $p = $wpdb->prefix;
    if ($p !== '' && substr((string) $suffix, 0, strlen($p)) === $p) {
        return $suffix;
    }
    return $wpdb->prefix . ltrim($suffix, '_');
}

/**
 * Get currency symbol based on currency code
 *
 * @param string|null $currency Currency code (MAD, EUR, USD, etc.)
 * @return string Currency symbol
 */
function ajtb_get_currency_symbol($currency = null) {
    if ($currency === null) {
        $currency = get_option('st_currency', 'MAD');
    }

    $symbols = [
        'MAD' => 'DH',
        'EUR' => '€',
        'USD' => '$',
        'GBP' => '£',
        'CHF' => 'CHF',
        'CAD' => 'CA$',
        'AED' => 'AED',
    ];

    return isset($symbols[$currency]) ? $symbols[$currency] : $currency;
}

/**
 * Format price with currency
 *
 * @param float $price Price value
 * @param bool $with_symbol Include currency symbol
 * @return string Formatted price
 */
function ajtb_format_price($price, $with_symbol = true) {
    $formatted = number_format((float)$price, 0, ',', ' ');
    
    if ($with_symbol) {
        return $formatted . ' ' . ajtb_get_currency_symbol();
    }
    
    return $formatted;
}

/**
 * Get tour thumbnail URL
 *
 * @param int $post_id Post ID
 * @param string $size Image size
 * @return string Image URL or placeholder
 */
function ajtb_get_tour_thumbnail($post_id, $size = 'large') {
    $thumbnail_id = get_post_thumbnail_id($post_id);
    
    if ($thumbnail_id) {
        $image = wp_get_attachment_image_url($thumbnail_id, $size);
        if ($image) {
            return $image;
        }
    }

    // Fallback placeholder
    return AJTB_PLUGIN_URL . 'assets/images/placeholder-tour.jpg';
}

/**
 * Safely unserialize data
 *
 * @param mixed $data Data to unserialize
 * @return mixed Unserialized data or original
 */
function ajtb_maybe_unserialize($data) {
    if (!is_string($data)) {
        return $data;
    }

    // Check if serialized
    if (preg_match('/^([adObis]):/', $data)) {
        $unserialized = @unserialize($data);
        if ($unserialized !== false) {
            return $unserialized;
        }
    }

    return $data;
}

/**
 * Parse gallery meta to array of image data
 *
 * @param mixed $gallery_meta Gallery meta value
 * @return array Array of image data
 */
function ajtb_parse_gallery($gallery_meta) {
    $images = [];
    
    if (empty($gallery_meta)) {
        return $images;
    }

    // Unserialize if needed
    $gallery = ajtb_maybe_unserialize($gallery_meta);

    // Handle comma-separated IDs
    if (is_string($gallery)) {
        $ids = array_filter(array_map('trim', explode(',', $gallery)));
    } elseif (is_array($gallery)) {
        $ids = $gallery;
    } else {
        return $images;
    }

    foreach ($ids as $attachment_id) {
        $attachment_id = (int) $attachment_id;
        if ($attachment_id <= 0) {
            continue;
        }

        $url = wp_get_attachment_url($attachment_id);
        if (!$url) {
            continue;
        }

        $images[] = [
            'id' => $attachment_id,
            'url' => $url,
            'thumbnail' => wp_get_attachment_image_url($attachment_id, 'thumbnail'),
            'medium' => wp_get_attachment_image_url($attachment_id, 'medium'),
            'large' => wp_get_attachment_image_url($attachment_id, 'large'),
            'alt' => get_post_meta($attachment_id, '_wp_attachment_image_alt', true),
        ];
    }

    return $images;
}

/**
 * Parse list content (HTML or newlines) to array
 *
 * @param string $content Content to parse
 * @return array Array of items
 */
function ajtb_parse_list_content($content) {
    if (empty($content)) {
        return [];
    }

    $items = [];

    // Check for <li> items
    if (strpos($content, '<li>') !== false) {
        preg_match_all('/<li>(.*?)<\/li>/si', $content, $matches);
        if (!empty($matches[1])) {
            $items = array_map('trim', array_map('strip_tags', $matches[1]));
        }
    } else {
        // Split by newlines or <br>
        $content = str_replace(['<br>', '<br/>', '<br />'], "\n", $content);
        $content = strip_tags($content);
        $items = array_filter(array_map('trim', explode("\n", $content)));
    }

    return array_values($items);
}

/**
 * Get star rating HTML
 *
 * @param float $rating Rating value (0-5)
 * @param int $max Maximum stars
 * @return string HTML output
 */
function ajtb_get_star_rating($rating, $max = 5) {
    $rating = max(0, min($max, (float)$rating));
    $full_stars = floor($rating);
    $half_star = ($rating - $full_stars) >= 0.5;
    $empty_stars = $max - $full_stars - ($half_star ? 1 : 0);

    $output = '<div class="ajtb-rating">';
    
    // Full stars
    for ($i = 0; $i < $full_stars; $i++) {
        $output .= '<svg class="star full" viewBox="0 0 24 24"><polygon fill="currentColor" points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26"/></svg>';
    }

    // Half star
    if ($half_star) {
        $output .= '<svg class="star half" viewBox="0 0 24 24"><defs><linearGradient id="half"><stop offset="50%" stop-color="currentColor"/><stop offset="50%" stop-color="#e0e0e0"/></linearGradient></defs><polygon fill="url(#half)" points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26"/></svg>';
    }

    // Empty stars
    for ($i = 0; $i < $empty_stars; $i++) {
        $output .= '<svg class="star empty" viewBox="0 0 24 24"><polygon fill="#e0e0e0" points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26"/></svg>';
    }

    $output .= '<span class="rating-value">' . number_format($rating, 1) . '</span>';
    $output .= '</div>';

    return $output;
}

/**
 * Load a partial template
 *
 * @param string $partial Partial name (without .php)
 * @param array $args Variables to pass to template
 * @return void
 */
function ajtb_get_partial($partial, $args = []) {
    $file = AJTB_PLUGIN_DIR . 'templates/tour/partials/' . $partial . '.php';

    if (!file_exists($file)) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            echo '<!-- Partial not found: ' . esc_html($partial) . ' -->';
        }
        return;
    }

    // Extract args to make them available in template
    if (!empty($args) && is_array($args)) {
        extract($args, EXTR_SKIP);
    }

    include $file;
}

/**
 * Sanitize and truncate text
 *
 * @param string $text Text to truncate
 * @param int $length Max length
 * @param string $suffix Suffix to add
 * @return string Truncated text
 */
function ajtb_truncate($text, $length = 150, $suffix = '...') {
    $text = wp_strip_all_tags($text);
    
    if (mb_strlen($text) <= $length) {
        return $text;
    }

    return mb_substr($text, 0, $length) . $suffix;
}

/**
 * Check if current page is our custom template
 *
 * @return bool
 */
function ajtb_is_tour_single() {
    return is_singular(AJTB_POST_TYPE);
}

/**
 * Get tour meta value with default
 *
 * @param int $post_id Post ID
 * @param string $key Meta key
 * @param mixed $default Default value
 * @return mixed Meta value or default
 */
function ajtb_get_meta($post_id, $key, $default = '') {
    $value = get_post_meta($post_id, $key, true);
    return ($value !== '' && $value !== false) ? $value : $default;
}

/**
 * Render HTML for one day's activities list + add block (for AJAX response).
 * Uses $wpdb->prefix via repository; no hardcoded table prefix.
 *
 * @param int $tour_id
 * @param int $day_id
 * @param array $day_activities List of activity items (title, description, activity_id, is_mandatory, is_included)
 * @param string $session_token
 * @param array $activities_catalog [['id'=>, 'title'=>], ...]
 * @return string HTML fragment (inner content for #aj-day-activities-{day_id})
 */
function ajtb_render_day_activities_html($tour_id, $day_id, $day_activities, $session_token, $activities_catalog = []) {
    $tour_id = (int) $tour_id;
    $day_id = (int) $day_id;
    $can_toggle = $tour_id > 0 && $day_id > 0 && $session_token !== '';
    $day_activity_ids = array_map(function ($a) {
        return (int) isset($a['activity_id']) ? $a['activity_id'] : 0;
    }, $day_activities);
    $included = array_filter($day_activities, function ($a) {
        return !empty($a['is_included']);
    });
    $included = array_values($included);

    $html = '<ul class="day-activities-list" data-day-id="' . esc_attr($day_id) . '">';
    if (!empty($included)) {
        foreach ($included as $act) {
            $act_id = (int) isset($act['activity_id']) ? $act['activity_id'] : 0;
            $title = isset($act['title']) && (string) $act['title'] !== '' ? $act['title'] : __('Activité', 'ajinsafro-tour-bridge');
            $desc = isset($act['description']) && (string) $act['description'] !== '' ? $act['description'] : '';
            $is_mandatory = !empty($act['is_mandatory']);
            $show_remove = $can_toggle && !$is_mandatory;
            $html .= '<li class="day-activity-item" data-activity-id="' . esc_attr($act_id) . '" data-is-mandatory="' . ($is_mandatory ? '1' : '0') . '">';
            $html .= '<span class="activity-title">' . esc_html($title) . '</span>';
            if ($is_mandatory) {
                $html .= ' <span class="badge badge-mandatory">' . esc_html__('Obligatoire', 'ajinsafro-tour-bridge') . '</span>';
            }
            if ($show_remove) {
                $html .= ' <button type="button" class="ajtb-btn-remove-activity" data-aj-action="remove" data-tour-id="' . esc_attr($tour_id) . '" data-day-id="' . esc_attr($day_id) . '" data-activity-id="' . esc_attr($act_id) . '" aria-label="' . esc_attr__('Retirer cette activité', 'ajinsafro-tour-bridge') . '">' . esc_html__('Retirer', 'ajinsafro-tour-bridge') . '</button>';
            }
            if ($desc !== '') {
                $html .= '<div class="activity-description">' . wp_kses_post($desc) . '</div>';
            }
            $html .= '</li>';
        }
    } else {
        $html .= '<li class="day-activity-item day-no-activities">' . esc_html__('Aucune activité', 'ajinsafro-tour-bridge') . '</li>';
    }
    $html .= '</ul>';
    if ($can_toggle && !empty($activities_catalog)) {
        $select_id = 'aj-add-select-' . $day_id;
        $html .= '<div class="day-add-activity" data-day-id="' . esc_attr($day_id) . '">';
        $html .= '<label for="' . esc_attr($select_id) . '">' . esc_html__('Ajouter une activité', 'ajinsafro-tour-bridge') . '</label>';
        $html .= '<select id="' . esc_attr($select_id) . '" class="ajtb-add-activity-select" data-day-id="' . esc_attr($day_id) . '">';
        $html .= '<option value="">— ' . esc_html__('Choisir', 'ajinsafro-tour-bridge') . ' —</option>';
        foreach ($activities_catalog as $c) {
            $cid = (int) isset($c['id']) ? $c['id'] : 0;
            if ($cid && !in_array($cid, $day_activity_ids, true)) {
                $ctitle = isset($c['title']) ? $c['title'] : '';
                $html .= '<option value="' . esc_attr($cid) . '">' . esc_html($ctitle) . '</option>';
            }
        }
        $html .= '</select>';
        $html .= ' <button type="button" class="ajtb-btn-add-activity" data-aj-action="add" data-tour-id="' . esc_attr($tour_id) . '" data-day-id="' . esc_attr($day_id) . '" data-select-id="' . esc_attr($select_id) . '">' . esc_html__('Ajouter', 'ajinsafro-tour-bridge') . '</button>';
        $html .= '</div>';
    }
    return $html;
}

/**
 * Render HTML for flights block (Flight Cards + Add/Remove). Used on initial load and AJAX response.
 *
 * @param int $tour_id
 * @param array $flights Displayed flights (after session selections)
 * @param array $all_flights All flights for tour (for "Add this flight" links)
 * @param string $session_token
 * @return string HTML fragment for #ajtb-flights-container
 */
function ajtb_render_flights_html($tour_id, $flights, $all_flights = [], $session_token = '') {
    $tour_id = (int) $tour_id;
    $can_toggle = $tour_id > 0 && $session_token !== '';
    $displayed_ids = array_column($flights, 'id');

    $html = '<div class="ajtb-flights-list" data-tour-id="' . esc_attr($tour_id) . '">';
    foreach ($flights as $f) {
        $dep_label = isset($f['depart_label']) ? $f['depart_label'] : '—';
        $arr_label = isset($f['arrive_label']) ? $f['arrive_label'] : '—';
        $dep_date = isset($f['depart_date_formatted']) ? $f['depart_date_formatted'] : '—';
        $arr_date = isset($f['arrive_date_formatted']) ? $f['arrive_date_formatted'] : '—';
        $dep_place = $dep_label;
        $arr_place = $arr_label;
        $cabin_bag = isset($f['cabin_baggage']) ? $f['cabin_baggage'] : '—';
        $checkin_bag = isset($f['checkin_baggage']) ? $f['checkin_baggage'] : '—';
        $tentative = !empty($f['is_tentative']);
        $flight_id = isset($f['id']) ? (int) $f['id'] : 0;

        $html .= '<div class="aj-flight-card" data-flight-id="' . esc_attr($flight_id) . '">';
        $html .= '<div class="aj-flight-header">';
        $html .= '<span class="aj-flight-title">✈ FLIGHT • ' . esc_html($dep_label) . ' to ' . esc_html($arr_label) . '</span>';
        if ($can_toggle) {
            $html .= ' <button type="button" class="ajtb-btn-remove-flight aj-flight-remove-btn" data-tour-id="' . esc_attr($tour_id) . '" data-flight-id="' . esc_attr($flight_id) . '" data-toggle-action="removed">' . esc_html__('Retirer', 'ajinsafro-tour-bridge') . '</button>';
        }
        $html .= '</div>';
        $html .= '<div class="aj-flight-body">';
        $html .= '<div class="aj-flight-col"><div class="aj-flight-icon"><span aria-hidden="true">✈</span></div></div>';
        $html .= '<div class="aj-flight-col aj-flight-center">';
        $html .= '<div class="aj-flight-dep"><div class="aj-flight-date">' . esc_html($dep_date) . '</div><div class="aj-flight-place">' . esc_html($dep_place) . '</div></div>';
        $html .= '<div class="aj-flight-arrow">→</div>';
        $html .= '<div class="aj-flight-arr"><div class="aj-flight-date">' . esc_html($arr_date) . '</div><div class="aj-flight-place">' . esc_html($arr_place) . '</div></div>';
        $html .= '</div>';
        $html .= '<div class="aj-flight-col aj-flight-baggage">';
        $html .= '<div>Cabin: ' . esc_html($cabin_bag) . '</div>';
        $html .= '<div>Check-in: ' . esc_html($checkin_bag) . '</div>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '<div class="aj-flight-badge-wrap">';
        if ($tentative) {
            $html .= '<span class="aj-flight-badge">' . esc_html__('Tentative Flight', 'ajinsafro-tour-bridge') . '</span>';
        }
        $html .= '</div>';
        $html .= '</div>';
    }

    if ($can_toggle && !empty($all_flights)) {
        $addable = array_filter($all_flights, function ($f) use ($displayed_ids) {
            $id = isset($f['id']) ? (int) $f['id'] : 0;
            return $id && !in_array($id, $displayed_ids, true);
        });
        if (!empty($addable)) {
            $html .= '<div class="ajtb-flights-add">';
            $html .= '<span class="ajtb-flights-add-label">' . esc_html__('Ajouter un vol', 'ajinsafro-tour-bridge') . ':</span> ';
            foreach ($addable as $f) {
                $fid = (int) $f['id'];
                $dep = isset($f['depart_label']) ? $f['depart_label'] : '—';
                $arr = isset($f['arrive_label']) ? $f['arrive_label'] : '—';
                $html .= '<button type="button" class="ajtb-btn-add-flight" data-tour-id="' . esc_attr($tour_id) . '" data-flight-id="' . esc_attr($fid) . '" data-toggle-action="added">' . esc_html($dep) . ' → ' . esc_html($arr) . '</button>';
            }
            $html .= '</div>';
        }
    }
    $html .= '</div>';
    return $html;
}

/**
 * Debug helper - only outputs in WP_DEBUG mode
 *
 * @param mixed $data Data to dump
 * @param string $label Optional label
 * @return void
 */
function ajtb_debug($data, $label = '') {
    if (!defined('WP_DEBUG') || !WP_DEBUG) {
        return;
    }

    echo '<!-- AJTB Debug';
    if ($label) {
        echo ' [' . esc_html($label) . ']';
    }
    echo ': ';
    echo esc_html(print_r($data, true));
    echo ' -->';
}
