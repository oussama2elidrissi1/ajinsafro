<?php
/**
 * Plugin Name: Ajinsafro Tour Bridge
 * Plugin URI: https://ajinsafro.ma
 * Description: Override single st_tours template with custom MakeMyTrip-style design. Combines WordPress tour data with Laravel custom tables.
 * Version: 1.0.0
 * Author: Ajinsafro
 * Author URI: https://ajinsafro.ma
 * Text Domain: ajinsafro-tour-bridge
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Plugin Constants
 */
define('AJTB_VERSION', '1.0.0');
define('AJTB_PLUGIN_FILE', __FILE__);
define('AJTB_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AJTB_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AJTB_POST_TYPE', 'st_tours');

/**
 * Laravel table suffix prefix (use ajtb_table() for full name to avoid double prefix).
 * Tables: ajtb_table('aj_tour_days'), ajtb_table('aj_tour_activity_selections'), etc.
 */
define('AJTB_LARAVEL_PREFIX', 'aj_');

/**
 * Load required files
 */
require_once AJTB_PLUGIN_DIR . 'includes/helpers.php';
require_once AJTB_PLUGIN_DIR . 'includes/class-tour-repository.php';
require_once AJTB_PLUGIN_DIR . 'includes/class-laravel-repository.php';
require_once AJTB_PLUGIN_DIR . 'includes/class-activity-selections.php';
require_once AJTB_PLUGIN_DIR . 'includes/class-template-loader.php';

/**
 * Initialize Plugin
 */
class Ajinsafro_Tour_Bridge {

    /**
     * Singleton instance
     * @var self|null
     */
    private static $instance = null;

    /**
     * Template Loader instance
     * @var AJTB_Template_Loader
     */
    public $template_loader;

    /**
     * Get singleton instance
     * @return self
     */
    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->init_hooks();
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Wait for plugins_loaded to ensure theme is ready
        add_action('plugins_loaded', [$this, 'init'], 20);
        
        // Activation hook
        register_activation_hook(AJTB_PLUGIN_FILE, [$this, 'activate']);
        
        // Deactivation hook
        register_deactivation_hook(AJTB_PLUGIN_FILE, [$this, 'deactivate']);
    }

    /**
     * Initialize plugin components
     */
    public function init() {
        // Initialize template loader
        $this->template_loader = new AJTB_Template_Loader();

        // Enqueue assets
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);

        // AJAX: client toggle optional activities (add/remove)
        add_action('wp_ajax_aj_toggle_activity', [$this, 'ajax_toggle_activity']);
        add_action('wp_ajax_nopriv_aj_toggle_activity', [$this, 'ajax_toggle_activity']);

        // Admin notice if Traveler not active
        add_action('admin_notices', [$this, 'admin_notices']);
    }

    /**
     * AJAX: toggle activity (added/removed) for client selection. Never modifies aj_tour_day_activities.
     * Persists in {$wpdb->prefix}aj_tour_activity_selections. Returns HTML for the day block.
     */
    public function ajax_toggle_activity() {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('AJ TOGGLE REQUEST ' . json_encode($_POST));
        }
        check_ajax_referer('aj_tour_activity', 'nonce');
        $tour_id = isset($_POST['tour_id']) ? (int) $_POST['tour_id'] : 0;
        $day_id = isset($_POST['day_id']) ? (int) $_POST['day_id'] : 0;
        $activity_id = isset($_POST['activity_id']) ? (int) $_POST['activity_id'] : 0;
        $action = isset($_POST['toggle_action']) ? sanitize_text_field($_POST['toggle_action']) : (isset($_POST['action_type']) ? sanitize_text_field($_POST['action_type']) : '');
        if (!in_array($action, ['added', 'removed'], true)) {
            wp_send_json_error(['message' => __('Action invalide.', 'ajinsafro-tour-bridge')]);
        }
        global $wpdb;
        $table_selections = ajtb_table('aj_tour_activity_selections');
        $show_tables_result = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_selections));
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('AJTB tables: wpdb->prefix=' . $wpdb->prefix . ', table_selections=' . $table_selections . ', SHOW TABLES result=' . ($show_tables_result ?: 'null'));
        }
        if ($show_tables_result != $table_selections) {
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            $charset_collate = $wpdb->get_charset_collate();
            $sql = "CREATE TABLE $table_selections (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                tour_id bigint(20) UNSIGNED NOT NULL,
                day_id bigint(20) UNSIGNED NOT NULL,
                activity_id bigint(20) UNSIGNED NOT NULL,
                source_day_activity_id bigint(20) UNSIGNED DEFAULT NULL,
                action varchar(20) NOT NULL DEFAULT 'added',
                session_token varchar(64) NOT NULL,
                user_id bigint(20) UNSIGNED DEFAULT NULL,
                created_at timestamp NULL DEFAULT NULL,
                updated_at timestamp NULL DEFAULT NULL,
                PRIMARY KEY (id),
                KEY session_token (session_token),
                KEY user_id (user_id),
                KEY tour_day_session (tour_id, day_id, session_token),
                UNIQUE KEY tour_day_activity_session (tour_id, day_id, activity_id, session_token)
            ) $charset_collate;";
            dbDelta($sql);
            $show_tables_after = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_selections));
            if ($show_tables_after != $table_selections) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('AJTB table create failed: ' . $table_selections);
                }
                wp_send_json_error(['message' => sprintf(__('Table selections missing: %s', 'ajinsafro-tour-bridge'), $table_selections)]);
            }
        }

        $selections = new AJTB_Activity_Selections();
        $session_token = isset($_POST['session_token']) ? sanitize_text_field($_POST['session_token']) : '';
        if ($session_token === '') {
            $session_token = $selections->get_session_token();
        }
        if (empty($tour_id) || empty($day_id) || empty($activity_id) || $session_token === '') {
            wp_send_json_error(['message' => __('Paramètres manquants.', 'ajinsafro-tour-bridge')]);
        }
        $user_id = is_user_logged_in() ? get_current_user_id() : null;
        $result = $selections->toggle($tour_id, $day_id, $activity_id, $action, $session_token, $user_id);
        if (empty($result['success'])) {
            wp_send_json_error(['message' => $result['message'] ?? __('Erreur.', 'ajinsafro-tour-bridge')]);
        }
        $day_activities = $result['day_activities'];
        $repo = new AJTB_Laravel_Repository($tour_id);
        $activities_catalog = $repo->get_activities_catalog();
        $html = ajtb_render_day_activities_html($tour_id, $day_id, $day_activities, $session_token, $activities_catalog);
        $count = is_array($day_activities) ? count(array_filter($day_activities, function ($a) {
            return !empty($a['is_included']);
        })) : 0;
        wp_send_json_success([
            'message' => $result['message'],
            'day_id' => $day_id,
            'html' => $html,
            'count' => $count,
        ]);
    }

    /**
     * Enqueue CSS and JS only on single st_tours
     */
    public function enqueue_assets() {
        // Only on single st_tours
        if (!is_singular(AJTB_POST_TYPE)) {
            return;
        }

        // Main CSS
        wp_enqueue_style(
            'ajtb-tour-css',
            AJTB_PLUGIN_URL . 'assets/css/tour.css',
            [],
            AJTB_VERSION
        );

        // Main JS
        wp_enqueue_script(
            'ajtb-tour-js',
            AJTB_PLUGIN_URL . 'assets/js/tour.js',
            ['jquery'],
            AJTB_VERSION,
            true
        );

        // Pass data to JS (ajax_url + nonce for aj_toggle_activity)
        $post_id = get_the_ID();
        wp_localize_script('ajtb-tour-js', 'ajtbData', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('aj_tour_activity'),
            'postId' => $post_id,
            'tour_id' => $post_id,
            'currency' => get_option('st_currency', 'MAD'),
            'currencySymbol' => ajtb_get_currency_symbol(),
        ]);
    }

    /**
     * Admin notices
     */
    public function admin_notices() {
        // Check if st_tours post type exists
        if (!post_type_exists(AJTB_POST_TYPE)) {
            echo '<div class="notice notice-warning is-dismissible">';
            echo '<p><strong>Ajinsafro Tour Bridge:</strong> ';
            echo 'Le post type <code>st_tours</code> n\'existe pas. ';
            echo 'Assurez-vous que le thème Traveler est actif.</p>';
            echo '</div>';
        }
    }

    /**
     * Plugin activation
     */
    public function activate() {
        // Flush rewrite rules
        flush_rewrite_rules();

        // Store version
        update_option('ajtb_version', AJTB_VERSION);

        // Create custom tables if needed
        $this->maybe_create_tables();
    }

    /**
     * Plugin deactivation
     */
    public function deactivate() {
        flush_rewrite_rules();
    }

    /**
     * Create Laravel custom tables if they don't exist (uses ajtb_table = single prefix)
     */
    private function maybe_create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        // Table: aj_tour_days
        $table_days = ajtb_table('aj_tour_days');
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_days)) != $table_days) {
            $sql = "CREATE TABLE $table_days (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                tour_id bigint(20) UNSIGNED NOT NULL,
                day_number int(11) NOT NULL DEFAULT 1,
                title varchar(255) DEFAULT NULL,
                description longtext DEFAULT NULL,
                meals varchar(255) DEFAULT NULL,
                accommodation varchar(255) DEFAULT NULL,
                image_url varchar(500) DEFAULT NULL,
                created_at timestamp NULL DEFAULT NULL,
                updated_at timestamp NULL DEFAULT NULL,
                PRIMARY KEY (id),
                KEY tour_id (tour_id),
                KEY day_number (day_number)
            ) $charset_collate;";
            dbDelta($sql);
        }

        // Table: aj_tour_sections
        $table_sections = ajtb_table('aj_tour_sections');
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_sections)) != $table_sections) {
            $sql = "CREATE TABLE $table_sections (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                tour_id bigint(20) UNSIGNED NOT NULL,
                section_key varchar(100) NOT NULL,
                content longtext DEFAULT NULL,
                sort_order int(11) NOT NULL DEFAULT 0,
                created_at timestamp NULL DEFAULT NULL,
                updated_at timestamp NULL DEFAULT NULL,
                PRIMARY KEY (id),
                KEY tour_id (tour_id),
                KEY section_key (section_key)
            ) $charset_collate;";
            dbDelta($sql);
        }

        // Table: aj_tour_pricing_rules
        $table_pricing = ajtb_table('aj_tour_pricing_rules');
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_pricing)) != $table_pricing) {
            $sql = "CREATE TABLE $table_pricing (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                tour_id bigint(20) UNSIGNED NOT NULL,
                season_name varchar(100) DEFAULT NULL,
                start_date date DEFAULT NULL,
                end_date date DEFAULT NULL,
                adult_price decimal(10,2) NOT NULL DEFAULT 0,
                child_price decimal(10,2) NOT NULL DEFAULT 0,
                infant_price decimal(10,2) NOT NULL DEFAULT 0,
                is_active tinyint(1) NOT NULL DEFAULT 1,
                created_at timestamp NULL DEFAULT NULL,
                updated_at timestamp NULL DEFAULT NULL,
                PRIMARY KEY (id),
                KEY tour_id (tour_id),
                KEY is_active (is_active)
            ) $charset_collate;";
            dbDelta($sql);
        }

        // Table: aj_tour_activity_selections (client add/remove optional activities; never modifies aj_tour_day_activities)
        $table_selections = ajtb_table('aj_tour_activity_selections');
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_selections)) != $table_selections) {
            $sql = "CREATE TABLE $table_selections (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                tour_id bigint(20) UNSIGNED NOT NULL,
                day_id bigint(20) UNSIGNED NOT NULL,
                activity_id bigint(20) UNSIGNED NOT NULL,
                source_day_activity_id bigint(20) UNSIGNED DEFAULT NULL,
                action varchar(20) NOT NULL DEFAULT 'added',
                session_token varchar(64) NOT NULL,
                user_id bigint(20) UNSIGNED DEFAULT NULL,
                created_at timestamp NULL DEFAULT NULL,
                updated_at timestamp NULL DEFAULT NULL,
                PRIMARY KEY (id),
                KEY session_token (session_token),
                KEY user_id (user_id),
                KEY tour_day_session (tour_id, day_id, session_token),
                UNIQUE KEY tour_day_activity_session (tour_id, day_id, activity_id, session_token)
            ) $charset_collate;";
            dbDelta($sql);
        }
    }
}

/**
 * Main function to get plugin instance
 * @return Ajinsafro_Tour_Bridge
 */
function AJTB() {
    return Ajinsafro_Tour_Bridge::instance();
}

// Initialize plugin
AJTB();
