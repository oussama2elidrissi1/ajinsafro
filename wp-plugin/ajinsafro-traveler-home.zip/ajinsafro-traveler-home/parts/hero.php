<?php
/**
 * Part: Hero + floating search bar
 * @package AjinsafroTravelerHome
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$hero_image_url = '';
if ( ! empty( $settings['hero_image'] ) ) {
    if ( is_numeric( $settings['hero_image'] ) ) {
        $hero_image_url = wp_get_attachment_image_url( absint( $settings['hero_image'] ), 'full' );
    } else {
        $hero_image_url = $settings['hero_image'];
    }
}
$hero_title    = ! empty( $settings['hero_title'] )    ? $settings['hero_title']    : 'Partir en vacances au Maroc';
$hero_subtitle = ! empty( $settings['hero_subtitle'] ) ? $settings['hero_subtitle'] : 'Avec meilleur prix !';
$bg = $hero_image_url
    ? 'background-image:url(' . esc_url( $hero_image_url ) . ');'
    : 'background:linear-gradient(135deg,#c2935a 0%,#8b6914 40%,#d4a04a 100%);';
?>

<section class="aj-hero" style="<?php echo esc_attr( $bg ); ?>">
    <div class="aj-hero__overlay"></div>
    <div class="aj-hero__center">
        <h1 class="aj-hero__title"><?php echo esc_html( $hero_title ); ?></h1>
        <?php if ( $hero_subtitle ) : ?>
            <p class="aj-hero__sub"><?php echo esc_html( $hero_subtitle ); ?></p>
        <?php endif; ?>
    </div>
    <div class="aj-search-float">
        <?php include AJTH_DIR . 'parts/search.php'; ?>
    </div>
</section>
