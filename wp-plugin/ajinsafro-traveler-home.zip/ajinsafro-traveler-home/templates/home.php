<?php
/**
 * Home Page Template
 *
 * @package AjinsafroTravelerHome
 */
if ( ! defined( 'ABSPATH' ) ) exit;

get_header();
$settings = ajth_get_settings();
?>

<div id="aj-home" class="aj-home">
    <?php include AJTH_DIR . 'parts/hero.php'; ?>
    <?php include AJTH_DIR . 'parts/last-minute.php'; ?>
    <?php include AJTH_DIR . 'parts/regions.php'; ?>
    <?php include AJTH_DIR . 'parts/good-spots.php'; ?>
</div>

<?php get_footer(); ?>
