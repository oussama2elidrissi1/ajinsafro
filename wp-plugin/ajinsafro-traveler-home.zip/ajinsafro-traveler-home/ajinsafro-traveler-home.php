<?php
/**
 * Plugin Name: Ajinsafro Traveler Home
 * Plugin URI:  https://ajinsafro.com
 * Description: Surcharge la page d'accueil (front page) du thème Traveler avec une mise en page personnalisée : Hero, barre de recherche, offres dernière minute, destinations par région et bons coins.
 * Version:     1.0.0
 * Author:      Ajinsafro
 * Author URI:  https://ajinsafro.com
 * Text Domain: ajinsafro-traveler-home
 * Domain Path: /languages
 * License:     GPLv2 or later
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* ──────────────────────────────────────────────
 * Constants
 * ────────────────────────────────────────────── */
define( 'AJTH_VERSION', '1.0.0' );
define( 'AJTH_FILE',    __FILE__ );
define( 'AJTH_DIR',     plugin_dir_path( __FILE__ ) );
define( 'AJTH_URL',     plugin_dir_url( __FILE__ ) );

/* ──────────────────────────────────────────────
 * Autoload includes
 * ────────────────────────────────────────────── */
require_once AJTH_DIR . 'includes/class-template-router.php';
require_once AJTH_DIR . 'includes/class-admin-settings.php';

/* ──────────────────────────────────────────────
 * Boot
 * ────────────────────────────────────────────── */
function ajth_init() {
    // Template routing (front-end)
    new AJTH_Template_Router();

    // Admin settings page
    if ( is_admin() ) {
        new AJTH_Admin_Settings();
    }
}
add_action( 'plugins_loaded', 'ajth_init' );

/* ──────────────────────────────────────────────
 * Enqueue front-end assets ONLY on the home page
 * ────────────────────────────────────────────── */
function ajth_enqueue_front_assets() {
    if ( ! is_front_page() && ! is_home() ) {
        return;
    }

    // Load AFTER the theme CSS so our rules win
    wp_enqueue_style(
        'ajth-home-css',
        AJTH_URL . 'assets/css/home.css',
        array(),
        AJTH_VERSION
    );

    wp_enqueue_script(
        'ajth-home-js',
        AJTH_URL . 'assets/js/home.js',
        array(),
        AJTH_VERSION,
        true
    );
}
add_action( 'wp_enqueue_scripts', 'ajth_enqueue_front_assets', 999 );

/* ──────────────────────────────────────────────
 * Helper: get plugin settings with defaults
 * ────────────────────────────────────────────── */
function ajth_get_settings() {
    $defaults = array(
        'hero_image'       => '',
        'hero_title'       => 'Partir en vacances au Maroc Avec meilleur prix !',
        'hero_subtitle'    => '',
        'last_minute_title' => 'Offres de dernière minute',
        'regions'          => array(),
        'good_spots'       => array(
            array( 'title' => 'Restaurants', 'image' => '', 'url' => '#' ),
            array( 'title' => 'Loisirs',     'image' => '', 'url' => '#' ),
            array( 'title' => 'Que faire ?',  'image' => '', 'url' => '#' ),
            array( 'title' => 'Shopping',     'image' => '', 'url' => '#' ),
        ),
    );

    $saved = get_option( 'ajth_home_settings', array() );

    return wp_parse_args( $saved, $defaults );
}

/* ──────────────────────────────────────────────
 * Activation: set default options if not present
 * ────────────────────────────────────────────── */
function ajth_activate() {
    if ( false === get_option( 'ajth_home_settings' ) ) {
        update_option( 'ajth_home_settings', array() );
    }
}
register_activation_hook( __FILE__, 'ajth_activate' );
